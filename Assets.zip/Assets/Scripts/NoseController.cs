﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NoseController : MonoBehaviour
{
    public Text countText; 
    private int count; 

    void Start ()
    {
        count = 0;
        countText.text = count.ToString();
    }
  
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Blueberry"))
        {
            other.gameObject.SetActive(false);
            count++;
            SetCountText ();
        }
    }

    void SetCountText ()
    {
        countText.text = count.ToString();
        
        if (count == 6)
        {
            countText.text = "All blueberrys eaten. Yummy!";                        
        }
    }

}
