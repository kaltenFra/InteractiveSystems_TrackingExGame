﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeMaterial : MonoBehaviour
{
    public Text countText; 
    private int count; 

    public Material[] material;
    Renderer rend;

    // Start is called before the first frame update
    void Start()
    {
        rend = GetComponent<Renderer>();
        rend.enabled = true;
        rend.sharedMaterial = material[0];
        count = 0;
        countText.text = count.ToString();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Hip"))
        {
            rend.sharedMaterial = material[1];

        }
        else if (other.gameObject.CompareTag("Hand"))
        {
            rend.sharedMaterial = material[2];
        }
        else if (other.gameObject.CompareTag("Nose"))
        {
            rend.sharedMaterial = material[0];

        }
        
        count++;
        countText.text = count.ToString();
    }

}
