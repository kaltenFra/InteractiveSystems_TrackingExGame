﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WristController : MonoBehaviour
{
    public Text countText; 
    private int count; 

    void Start ()
    {
        count = 0;
        countText.text = count.ToString();
    }


    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Coin"))
        {
            other.gameObject.SetActive(false);
            count++;
            countText.text = count.ToString();
        }
    }
}
